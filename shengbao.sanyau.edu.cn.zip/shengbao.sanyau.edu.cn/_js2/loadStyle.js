var sys_path = $("script[sys-path]").attr("sys-path");
sys_path += "?tt=" + Math.random();

var path = $("script[site-path]").attr("site-path");
path += "?tt=" + Math.random();
document.write("<link type='text/css' rel=\"stylesheet\" href='" + sys_path + "'>")
document.write("<link type='text/css' rel=\"stylesheet\" href='" + path + "'>")